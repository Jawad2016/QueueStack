/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.stackqueue;

/**
 *
 * @author Jawad Royesh
 */
public class StackQueue {
    Node top;

    public StackQueue() {
        top= null;
    }
    public boolean isEmpty(){
        return top ==null;
    }
   public void push(int item ){
   
       Node newnode = new Node(item);
       if(isEmpty()){
       
           top = newnode;
       }
       else {
       
           newnode.next= top;
           top = newnode;
       }
   }
       
   public int pop(){
   
       if(isEmpty()){
      
           System.out.println("Stack is empty, can't be popde");
           return -1;
       }
       else {
       
//           Node temp = top;
           int poped = top.data;
           top = top.next;
           return poped;
       }
   }
       public void show(){
       
           Node temp = top;
           while(temp != null){
               System.out.println(temp.data);
               temp = temp.next;
           
       }
       
   }
}
