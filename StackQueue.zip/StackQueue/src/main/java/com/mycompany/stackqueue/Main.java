/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.stackqueue;

/**
 *
 * @author Jawad Royesh
 */
public class Main {
    public static void main(String[] args){
        StackQueue stack = new StackQueue();
        stack.push(34);
        stack.push(55);
        stack.push(66);
//        stack.show();
//        System.out.println("After poped");
        
        stack.pop();
        stack.show();
//        System.out.println(popded);
    }
}
