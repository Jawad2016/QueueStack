/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Queue;

/**
 *
 * @author Jawad Royesh
 */
public class Qeueue {
    Node front;
    Node rear;
    public Qeueue() {
        this.front = null;
        this.rear = null;
    }
    
    public boolean isEmpty(){
        return front  == null;
    }
    public void enqueue(int item){
        Node newnode = new Node(item);
        
        if(isEmpty()){
        
            front = rear = newnode;
        }
        
        else {
        
            rear.link= newnode;
            rear = newnode;
        }
        
    }
    public void show(){
    
        if(isEmpty()){
            System.out.println("Stack is empty, Can't to be show data");
        }
        Node temp = front;
        while(temp != null){
        
            temp = temp.link;
        }
    }
}
