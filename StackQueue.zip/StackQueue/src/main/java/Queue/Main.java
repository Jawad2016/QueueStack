/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Queue;

/**
 *
 * @author Jawad Royesh
 */
public class Main {
    public static void main(String[] args){
    
        Qeueue queue = new Qeueue();
        queue.enqueue(45);
        queue.enqueue(66);
        queue.enqueue(99);
        queue.enqueue(100);
        queue.show();
    
    
    }
    
}
